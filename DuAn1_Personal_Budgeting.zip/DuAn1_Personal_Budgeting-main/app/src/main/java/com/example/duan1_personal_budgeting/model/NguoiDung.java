package com.example.duan1_personal_budgeting.model;

public class NguoiDung {
    private int nguoiDungID;
    private String tenNguoiDung;
    private String email;
}
